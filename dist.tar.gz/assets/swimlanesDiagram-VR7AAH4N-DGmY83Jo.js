import{n as e}from"./chunk-Y2CYZVJY-DsF7k-Jl.js";import"./src-BxJJ3_e0.js";import"./chunk-DU6HZSFF-BnxJQNps.js";import"./chunk-75Z2AOVW-B5-2sJ3p.js";import"./chunk-P2QGCYS3-kcZxgzE4.js";import"./chunk-PWAF6VOD-BsTnOyIZ.js";import"./chunk-GMAD6QVW-8clYwc26.js";import"./chunk-4HAMMTFA-DyT5ORgt.js";import"./chunk-GVQU2GXP-CUr5LZaS.js";import"./chunk-L3NEJ4N5-BahQhqT8.js";import"./chunk-OSK3NFVY-DLp1blHV.js";import"./dist-CZFJXIfu.js";import"./chunk-F27PBJKO-B9b6h_aH.js";import"./chunk-XXDRQBXY-BrqNE42E.js";import"./chunk-POPQ4Y6H-BvtU8bXS.js";import{r as t,t as n}from"./chunk-SHT3W25Y-DN33zBzd.js";var r=n({defaultLayout:`swimlane`,styles:e(e=>`${t(e)}
  .swimlane.cluster rect {
    stroke: ${e.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,`getStyles`)});export{r as diagram};