import{n as e}from"./chunk-Y2CYZVJY-DsF7k-Jl.js";import"./src-D_XzzD8X.js";import"./chunk-DU6HZSFF-BGNq_MVb.js";import"./chunk-75Z2AOVW-DgWPxhni.js";import"./chunk-P2QGCYS3-mkUA6QsW.js";import"./chunk-PWAF6VOD-DWvdeBwr.js";import"./chunk-GMAD6QVW-C_Qj-NoN.js";import"./chunk-4HAMMTFA-CjLP4kvC.js";import"./chunk-GVQU2GXP-OQatxRg8.js";import"./chunk-L3NEJ4N5-DgT2mNij.js";import"./chunk-OSK3NFVY-hGnjaDki.js";import"./dist-Ci7UMMWO.js";import"./chunk-F27PBJKO-D32ae4y1.js";import"./chunk-XXDRQBXY-CG3ICIPF.js";import"./chunk-POPQ4Y6H-BfCSJhnG.js";import{r as t,t as n}from"./chunk-SHT3W25Y-CGWp-5OI.js";var r=n({defaultLayout:`swimlane`,styles:e(e=>`${t(e)}
  .swimlane.cluster rect {
    stroke: ${e.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,`getStyles`)});export{r as diagram};